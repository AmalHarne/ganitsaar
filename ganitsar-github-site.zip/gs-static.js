/* Ganitsar static mode (GitHub Pages). No server: the admin site saves classes, tests and study material into
   data.json in the GitHub repository (through the GitHub API, using the admin's token), and the student site
   reads the same data.json. Built-in tests are read from class*-tests.json / class*-more.json files. */
(function () {
  var JOIN_CODE = '0770', ADMIN_PASSCODE = '24022014', BASE = 1000000;
  var DEFAULT_REPO = 'amalharne/ganitsaar5---10.com', DEFAULT_BRANCH = 'main';
  var LS = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
             set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
             del: function (k) { try { localStorage.removeItem(k); } catch (e) {} } };
  function cfg() { try { return JSON.parse(LS.get('gs-gh') || '{}'); } catch (e) { return {}; } }
  function isAdmin() { return LS.get('gs-admin') === '1'; }
  function err(status, msg) { var e = new Error(msg); e.status = status; return e; }
  var CHAPTER_COUNT = { 5: 16, 6: 19, 7: 15, 8: 17, 9: 16, 10: 13 };

  // ---------- shared data (data.json) ----------
  var data = null, dataSha = null;
  function emptyData() { return { nextId: 1, classes: [], tests: [], materials: [] }; }
  async function loadData(force) {
    if (data && !force) return data;
    var r = await fetch('data.json?ts=' + Date.now(), { cache: 'no-store' }).catch(function () { return null; });
    data = r && r.ok ? await r.json().catch(function () { return emptyData(); }) : emptyData();
    ['classes', 'tests', 'materials'].forEach(function (k) { if (!Array.isArray(data[k])) data[k] = []; });
    if (!data.nextId) data.nextId = 1;
    return data;
  }
  function ghHeaders(c) { return { Authorization: 'Bearer ' + c.token, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' }; }
  function b64(s) { return btoa(unescape(encodeURIComponent(s))); }
  // Read the newest data.json from GitHub, apply change(d), save it back (retries if someone else saved first).
  async function mutate(change) {
    var c = cfg(); if (!c.token) throw err(403, 'Save your GitHub token first (Admin settings at the top of the page).');
    var repo = c.repo || DEFAULT_REPO, branch = c.branch || DEFAULT_BRANCH, url = 'https://api.github.com/repos/' + repo + '/contents/data.json';
    for (var attempt = 0; attempt < 3; attempt++) {
      var g = await fetch(url + '?ref=' + encodeURIComponent(branch) + '&ts=' + Date.now(), { headers: ghHeaders(c), cache: 'no-store' });
      var d, sha = null;
      if (g.status === 404) d = emptyData();
      else if (g.ok) { var j = await g.json(); sha = j.sha; try { d = JSON.parse(decodeURIComponent(escape(atob(String(j.content).replace(/\s/g, ''))))); } catch (e) { d = emptyData(); } }
      else if (g.status === 401 || g.status === 403) throw err(403, 'GitHub refused the token. Check that the token is correct, not expired, and allowed to write to ' + repo + '.');
      else throw err(g.status, 'Could not read ' + repo + ' on GitHub (' + g.status + ').');
      ['classes', 'tests', 'materials'].forEach(function (k) { if (!Array.isArray(d[k])) d[k] = []; });
      if (!d.nextId) d.nextId = 1;
      var out = change(d);
      var body = { message: 'Ganitsar admin update', content: b64(JSON.stringify(d)), branch: branch }; if (sha) body.sha = sha;
      var p = await fetch(url, { method: 'PUT', headers: Object.assign({ 'Content-Type': 'application/json' }, ghHeaders(c)), body: JSON.stringify(body) });
      if (p.ok) { data = d; return out; }
      if (p.status === 409 || p.status === 422) continue;   // changed meanwhile: read again and retry
      if (p.status === 401 || p.status === 403 || p.status === 404) throw err(403, 'GitHub refused to save (' + p.status + '). The token needs "Contents: Read and write" on ' + repo + '.');
      throw err(p.status, 'GitHub could not save (' + p.status + ').');
    }
    throw err(409, 'Someone else saved at the same time. Please try again.');
  }

  // ---------- built-in tests (lazy, one class at a time) ----------
  var builtin = {}, loaded = {};
  async function loadBuiltin(std) {
    if (loaded[std]) return loaded[std];
    loaded[std] = (async function () {
      var k = std - 5, out = [];
      var a = await fetch('class' + std + '-tests.json').then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; });
      a.forEach(function (t, i) { out.push({ id: BASE + k * 1000 + i, set: 1, t: t }); });
      var b = await fetch('class' + std + '-more.json').then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; });
      b.forEach(function (t, i) { out.push({ id: BASE + k * 1000 + 500 + i, set: t.set || 1, t: t }); });
      out.forEach(function (o) { builtin[o.id] = o; });
      return out;
    })();
    return loaded[std];
  }
  var loc = function (v, lang) { return v && typeof v === 'object' && !Array.isArray(v) ? (v[lang] || v.en || v.mr || '') : v; };
  var iso = function () { return new Date().toISOString(); };
  var live = function (x) { return !x.expires_at || x.expires_at > iso(); };

  // ---------- the API the pages call ----------
  var attempts = {}, attemptSeq = 0;
  window.gsStaticApi = async function (url, opts) {
    opts = opts || {}; var method = (opts.method || 'GET').toUpperCase(), body = {}; try { body = opts.body ? JSON.parse(opts.body) : {}; } catch (e) {}
    var u = new URL(url, location.href), p = u.pathname.replace(/^.*?(\/api\/|\/auth\/)/, '$1'), m;
    if (p === '/auth/admin') { if (String(body.passcode) !== ADMIN_PASSCODE) throw err(403, 'Wrong passcode.'); LS.set('gs-admin', '1'); return { ok: true }; }
    if (p === '/auth/logout') { LS.del('gs-admin'); return { ok: true }; }
    if (p === '/api/me') return { user: { id: LS.get('gs-gid') || (function () { var g = 'g' + Math.random().toString(36).slice(2, 12); LS.set('gs-gid', g); return g; })(), name: isAdmin() ? 'Admin' : 'Student', role: isAdmin() ? 'admin' : 'student' }, joined: isAdmin() || LS.get('gs-joined') === '1', adminConfigured: true };
    if (p === '/api/classes/join') { if (String(body.code || '').trim() !== JOIN_CODE) throw err(403, 'Wrong join code.'); LS.set('gs-joined', '1'); return { ok: true }; }
    var d = await loadData(method === 'GET' && p !== '/api/me' ? false : false);
    if (p === '/api/classes' && method === 'GET') {
      var cutoff = new Date(Date.now() - 2 * 3600000).toISOString(), can = isAdmin() || LS.get('gs-joined') === '1';
      return d.classes.filter(function (c) { return c.start_at >= cutoff; }).sort(function (a, b) { return a.start_at < b.start_at ? -1 : 1; })
        .map(function (c) { return can ? c : Object.assign({}, c, { meeting_link: null }); });
    }
    if (p === '/api/materials' && method === 'GET') return d.materials.filter(live);
    if (p === '/api/tests' && method === 'GET') {
      var lang = u.searchParams.get('lang') === 'mr' ? 'mr' : 'en', all = [];
      for (var s = 5; s <= 10; s++) (await loadBuiltin(s)).forEach(function (o) { var t = o.t; all.push({ id: o.id, set: o.set, title: loc(t.title, lang), standard: t.standard, ch: t.ch, duration_min: t.durationMin, question_count: t.qs.length, builtin: true }); });
      d.tests.filter(live).forEach(function (t) { all.push({ id: t.id, title: t.title, standard: t.standard, ch: t.ch, duration_min: t.duration_min, question_count: t.question_count, expires_at: t.expires_at, created_by: t.created_by, builtin: false }); });
      all.forEach(function (t) { var ls = LS.get('gs-score-' + t.id); t.last_score = ls ? JSON.parse(ls) : null; });
      all.sort(function (x, y) { return x.standard - y.standard || (x.ch == null ? -1 : x.ch) - (y.ch == null ? -1 : y.ch) || (y.builtin ? 1 : 0) - (x.builtin ? 1 : 0) || x.id - y.id; });
      return all;
    }
    if ((m = p.match(/^\/api\/tests\/(\d+)\/start$/)) && method === 'POST') {
      var id = Number(m[1]), t, lang2 = body.lang === 'mr' ? 'mr' : 'en';
      if (id >= BASE) { await loadBuiltin(Math.floor((id - BASE) / 1000) + 5); var o = builtin[id]; if (!o) throw err(404, 'Test not found.'); t = { title: o.t.title, duration_min: o.t.durationMin, qs: o.t.qs }; }
      else { var r = d.tests.find(function (x) { return x.id === id; }); if (!r) throw err(404, 'Test not found.'); if (!live(r)) throw err(410, 'This test is no longer available.'); t = { title: r.title, duration_min: r.duration_min, qs: r.qs }; }
      var now = Date.now(), aid = ++attemptSeq; attempts[aid] = { id: id, qs: t.qs, start: now, dur: t.duration_min };
      return { attemptId: aid, title: loc(t.title, lang2), duration_min: t.duration_min, serverNow: now, endsAt: now + t.duration_min * 60000,
        questions: t.qs.map(function (q) { return { q: loc(q.q, lang2), opts: q.opts.map(function (x) { return loc(x, lang2); }) }; }) };
    }
    if ((m = p.match(/^\/api\/tests\/(\d+)\/submit$/)) && method === 'POST') {
      var at = attempts[body.attemptId]; if (!at || at.id !== Number(m[1])) throw err(404, 'Attempt not found.');
      if (Date.now() > at.start + at.dur * 60000 + 60000) throw err(400, 'Time is over for this attempt.');
      var given = Array.isArray(body.answers) ? body.answers : [], answers = at.qs.map(function (_, i) { var n = Number(given[i]); return given[i] != null && Number.isInteger(n) && n >= 0 && n <= 3 ? n : null; });
      var score = at.qs.reduce(function (s, q, i) { return s + (answers[i] === q.a ? 1 : 0); }, 0); delete attempts[body.attemptId];
      LS.set('gs-score-' + at.id, JSON.stringify({ score: score, total: at.qs.length }));
      return { score: score, total: at.qs.length, answers: answers, correct: at.qs.map(function (q) { return q.a; }) };
    }
    if ((m = p.match(/^\/api\/tests\/(\d+)\/results$/))) return [];   // static hosting does not keep student scores
    // ----- admin writes -----
    if (!isAdmin()) throw err(403, 'Admin only. Open the admin site and enter the admin passcode.');
    var clip = function (s, n) { return String(s == null ? '' : s).trim().slice(0, n); };
    var stdOf = function (v) { var n = parseInt(v, 10); return n >= 5 && n <= 10 ? n : null; };
    var chFor = function (std, v) { var n = parseInt(v, 10); return CHAPTER_COUNT[std] && Number.isInteger(n) && n >= 0 && n < CHAPTER_COUNT[std] ? n : null; };
    var expiry = function (v) { var mm = parseInt(v, 10); return mm >= 1 && mm <= 43200 ? new Date(Date.now() + mm * 60000).toISOString() : null; };
    if (p === '/api/classes' && method === 'POST') {
      var std = stdOf(body.standard), title = clip(body.title, 200), link = clip(body.meetingLink, 1000), start = new Date(body.date + 'T' + body.time + ':00+05:30');
      if (!title) throw err(400, 'Title is required.'); if (!std) throw err(400, 'Choose a class from 5 to 10.'); if (isNaN(start)) throw err(400, 'A valid date and time are required.');
      if (!/^https?:\/\//i.test(link)) throw err(400, 'Enter a valid meeting link .');
      return mutate(function (x) { var row = { id: x.nextId++, title: title, standard: std, topic: clip(body.topic, 200) || null, ch: chFor(std, body.ch), description: clip(body.description, 2000) || null, start_at: start.toISOString(), duration_min: Math.min(Math.max(parseInt(body.durationMin, 10) || 60, 15), 300), meeting_link: link, created_by: 'Admin', created_at: iso() }; x.classes.push(row); return row; });
    }
    if ((m = p.match(/^\/api\/classes\/(\d+)$/)) && method === 'DELETE') return mutate(function (x) { x.classes = x.classes.filter(function (c) { return c.id !== Number(m[1]); }); return { ok: true }; });
    if (p === '/api/tests' && method === 'POST') {
      var s2 = stdOf(body.standard), t2 = clip(body.title, 200), ch2 = chFor(s2, body.ch), dur = Math.min(Math.max(parseInt(body.durationMin, 10) || 10, 1), 180);
      if (!t2) throw err(400, 'Title is required.'); if (!s2) throw err(400, 'Choose a class from 5 to 10.'); if (CHAPTER_COUNT[s2] && ch2 === null) throw err(400, 'Choose a chapter for a Class ' + s2 + ' test.');
      if (!Array.isArray(body.qs) || body.qs.length < 1 || body.qs.length > 100) throw err(400, 'A test needs 1 to 100 questions.');
      var qs = body.qs.map(function (q) { var a = parseInt(q && q.a, 10), opts = Array.isArray(q && q.opts) ? q.opts.map(function (o) { return clip(o, 200); }) : [], tx = clip(q && q.q, 500); if (!tx || opts.length !== 4 || opts.some(function (o) { return !o; }) || !(a >= 0 && a <= 3)) throw err(400, 'Every question needs text, four options and one correct answer.'); return { q: tx, opts: opts, a: a }; });
      return mutate(function (x) { var row = { id: x.nextId++, title: t2, standard: s2, ch: ch2, duration_min: dur, question_count: qs.length, qs: qs, expires_at: expiry(body.visibleMin), created_by: 'Admin', created_at: iso() }; x.tests.push(row); return { id: row.id }; });
    }
    if ((m = p.match(/^\/api\/tests\/(\d+)$/)) && method === 'DELETE') { if (Number(m[1]) >= BASE) throw err(400, 'Built-in tests cannot be deleted.'); return mutate(function (x) { x.tests = x.tests.filter(function (t) { return t.id !== Number(m[1]); }); return { ok: true }; }); }
    if (p === '/api/materials' && method === 'POST') {
      var s3 = stdOf(body.standard), t3 = clip(body.title, 200), notes = clip(body.notes, 5000) || null, l3 = clip(body.link, 1000) || null;
      if (!t3) throw err(400, 'Title is required.'); if (!s3) throw err(400, 'Choose a class from 5 to 10.'); if (l3 && !/^https?:\/\//i.test(l3)) throw err(400, 'The link must start with https://');
      if (body.photo) throw err(400, 'Photos are not supported on the GitHub version. Use notes or a link.'); if (!notes && !l3) throw err(400, 'Add notes or a link.');
      return mutate(function (x) { var row = { id: x.nextId++, title: t3, standard: s3, ch: chFor(s3, body.ch), notes: notes, link: l3, photo: null, medium: body.medium === 'en' || body.medium === 'mr' ? body.medium : null, created_by: 'Admin', expires_at: expiry(body.visibleMin), created_at: iso() }; x.materials.push(row); return row; });
    }
    if ((m = p.match(/^\/api\/materials\/(\d+)$/)) && method === 'DELETE') return mutate(function (x) { x.materials = x.materials.filter(function (r) { return r.id !== Number(m[1]); }); return { ok: true }; });
    throw err(404, 'Not found.');
  };
  window.gsStaticCfg = { get: cfg, set: function (c) { LS.set('gs-gh', JSON.stringify(c)); }, DEFAULT_REPO: DEFAULT_REPO, DEFAULT_BRANCH: DEFAULT_BRANCH, reload: function () { data = null; } };
})();
